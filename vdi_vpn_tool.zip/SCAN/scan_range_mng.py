#

sampling_total_file = 'result_host_discovery_(total_range_sampling).gnmap'

dev_range = [
'10.45.0.0',
'10.46.0.0',
'10.162.0.0',
'10.163.0.0',
'10.164.0.0',
'10.169.0.0'
]
not_dev_range = [
'10.11.0.0',
'10.12.0.0',
'10.13.0.0',
'10.14.0.0',
'10.41.0.0',
'10.42.0.0',
'10.43.0.0',
'10.44.0.0',
'10.47.0.0',
'10.48.0.0',
'10.111.0.0',
'10.112.0.0',
'10.113.0.0',
'10.114.0.0',
'10.119.0.0',
'10.212.0.0',
'10.213.0.0',
'10.214.0.0',
'10.219.0.0'
]

result_dev_range = []
result_not_dev_range = []

with open(sampling_total_file, 'r') as fp:
    tmp = fp.readlines()
    for t in tmp:
        if t[0] == '#' or t == '':
            continue
        try:
            ip_tmp = t.split('.')
            a = ip_tmp[0]
            b = ip_tmp[1]
            c = ip_tmp[2]
            d = ip_tmp[3]
        except Exception as e:
            print(f'ip: {t} - {str(e)}')
            continue

        
        if f'10.{b}.0.0' in dev_range:
            if not f'10.{b}.{c}.0/24' in result_dev_range:
                result_dev_range.append(f'10.{b}.{c}.0/24')
        elif f'10.{b}.0.0' in not_dev_range:
            if not f'10.{b}.{c}.0/24' in result_not_dev_range:
                result_not_dev_range.append(f'10.{b}.{c}.0/24')
            
with open('target_host_discovery_dev_range.txt', 'w') as fp:
    for h in result_dev_range:
        fp.write(f'{h}\n')

with open('target_host_discovery_not_dev_range.txt', 'w') as fp:
    for h in result_not_dev_range:
        fp.write(f'{h}\n')


