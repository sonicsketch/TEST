from scapy.all import sniff, ICMP, IP, Raw
import base64
import signal

received_chunks = {}
expected_total_chunks = None   # 총 수신 청크 수
filename = "security_test.bin" 

def handle_interrupt(signum, frame):
    """Convert Ctrl+C into a controlled shutdown of the capture loop."""
    raise KeyboardInterrupt

def handle_icmp(packet):
    global expected_total_chunks, filename

    if packet.haslayer(ICMP) and packet[ICMP].type == 8 and packet.haslayer(Raw):
        seq = packet[ICMP].seq  # 시퀀스 번호는 ICMP 헤더에서 추출
        raw_bytes = packet[Raw].load

        if seq == 0:
            try:
                meta_parts = raw_bytes.decode().split("::")
                if len(meta_parts) == 2:
                    filename = meta_parts[0]
                    expected_total_chunks = int(meta_parts[1]) # -1 meta 1제외
                    print(f"[META] Filename: {filename}, Total chunks: {expected_total_chunks}")
                else:
                    print(f"Error META format: {raw_bytes}")
            except Exception as e:
                print(f"Error parsing META: {e}")
            return
        
        if seq in received_chunks:
            return
        
        # 일반 데이터 청크 저장(:: 기준으로 시퀀스 떼고 저장)
        chunk = raw_bytes.decode('ascii')
        try:
            _, b64_payload = chunk.split("::", 1)  # 앞쪽 시퀀스는 무시
            received_chunks[seq] = b64_payload
            # print(f"- Received #{seq}: {b64_payload[:30]}...")
            print(f"- Received {len(received_chunks)} / Expected {expected_total_chunks}")
        except ValueError:
            print(f"Error seq={seq}: {chunk}")

def save_file_from_chunks():
    if not received_chunks:
        print("No data")
        return

    ordered_data = "".join(chunk for _, chunk in sorted(received_chunks.items()))

    def fix_base64_padding(s): # padding보정 (4의배수)
        return s + "=" * (-len(s) % 4)

    try:
        # decoded = base64.b64decode(ordered_data) #padding 보정으로 수정
        ordered_data_padded = fix_base64_padding(ordered_data)
        decoded = base64.b64decode(ordered_data_padded)
        with open(filename, "wb") as f:
            f.write(decoded)
        print(f"Success '{filename}' ({len(decoded)} bytes)")
    except Exception as e:
        print(f"Error decoding or saving file: {e}")
        return

if __name__ == "__main__":
    print("- Waiting(type 8)...")

    signal.signal(signal.SIGINT, handle_interrupt)

    # stop_filter를 통해 자동 종료 조건 설정
    def should_stop(pkt):
        return expected_total_chunks is not None and len(received_chunks) >= (expected_total_chunks) #meta 제외(-1)

    try:
        sniff(filter="icmp", prn=handle_icmp, store=0, stop_filter=should_stop)
    except KeyboardInterrupt:
        print("\nCtrl+C received. Receiver stopped.")
        raise SystemExit(0)

    print("\n Reconstructing file...")
    save_file_from_chunks()

